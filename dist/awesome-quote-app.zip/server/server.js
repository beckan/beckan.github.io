const express = require("express");
const app = express();
const port = 3000;

app.get("/api", async (req, res) => {
  const result = await fetch(
    "https://inspirational-quote-api-bb352c5f8754.herokuapp.com/quotes/random",
    {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "API-Key": "1f6c42c80b23",
      },
    }
  );

  // Parse the JSON response
  const data = await result.json();

  res.json(data);
});

app.use(express.static("../"));

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
