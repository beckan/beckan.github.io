function initApplication() {
  // Get the list where we will add the quotes
  const list = document.querySelector("#quote-list");

  // Setup on click event listener for the "Add new quote" button
  document
    .getElementById("add-new-quote")
    .addEventListener("click", addNewQuote);

  // A scoped function to add a new quote component. I put it here to not expose it to the window object.
  function addNewQuote() {
    const component = new QuoteComponent();
    list.appendChild(component.elmRoot);
  }
}

// Wait for the DOM to be ready before we start the application
// For this small application this is not necessary, but it is a good practice
document.addEventListener("DOMContentLoaded", initApplication);
