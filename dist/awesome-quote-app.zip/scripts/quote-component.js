// Class to handle Quote component functionality
class QuoteComponent {
  constructor() {
    // Create all elements for the component
    this._createElements();

    // Fetch a random quote from the API
    this._fetchQuote();
  }

  /*
   * Public methods
   */
  remove() {
    this.elmRoot.remove();
  }

  shuffle() {
    this._fetchQuote();
  }

  /*
   * Private methods
   */
  _setAsPending() {
    this.elmRoot.classList.add("c-quote--is-pending");
  }

  _setAsAccessible() {
    this.elmRoot.classList.remove("c-quote--is-pending");
  }

  _createElements() {
    // Using createElement instead of innerHTML to improve performance and be able to easily add event listeners
    // It's getting a bit noisy, an other approach would be to use a template literal and then use innerHTML,
    // but that would not allow us to add event listeners easily
    this.elmRoot = document.createElement("div");
    this.elmRoot.className = "c-quote";

    this.elmSpinner = document.createElement("div");
    this.elmSpinner.className = "c-quote__spinner";
    this.elmSpinner.innerHTML = "Loading...";
    this.elmRoot.appendChild(this.elmSpinner);

    this.elmContent = document.createElement("div");
    this.elmContent.className = "c-quote__content";
    this.elmRoot.appendChild(this.elmContent);

    this.elmText = document.createElement("q");
    this.elmText.className = "c-quote__text";
    this.elmContent.appendChild(this.elmText);

    this.elmAuthor = document.createElement("span");
    this.elmAuthor.className = "c-quote__author";
    this.elmContent.appendChild(this.elmAuthor);

    this.elmImage = document.createElement("img");
    this.elmImage.className = "c-quote__image";
    this.elmRoot.appendChild(this.elmImage);

    this.elmActions = document.createElement("div");
    this.elmActions.className = "c-quote__actions";
    this.elmRoot.appendChild(this.elmActions);

    // Add action button for shuffle
    this.elmActionShuffle = document.createElement("button");
    this.elmActionShuffle.className = "c-button";
    this.elmActionShuffle.textContent = "Shuffle";

    this.elmActionShuffle.addEventListener("click", () => {
      this.shuffle();
    });
    this.elmActions.appendChild(this.elmActionShuffle);

    // Add action button for remove
    this.elmActionRemove = document.createElement("button");
    this.elmActionRemove.className = "c-button";
    this.elmActionRemove.textContent = "Remove";

    this.elmActionRemove.addEventListener("click", () => {
      this.remove();
    });
    this.elmActions.appendChild(this.elmActionRemove);
  }

  async _fetchQuote() {
    // Set the component state as pending to show a spinner and indicate for the user that we are fetching data
    this._setAsPending();

    // Create a quote object to hold the data
    const quote = {
      quote: null,
      person: null,
      image: null,
    };

    try {
      // Fetch a random quote from the API
      const result = await fetch(
        "https://inspirational-quote-api-bb352c5f8754.herokuapp.com/quotes/random",
        // "http://localhost:3000/api", My proxy to get around CORS issues
        {
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            "API-Key": "1f6c42c80b23", // Include the API key in the headers
          },
        }
      );

      // Parse the JSON response
      const data = await result.json();

      // If the API returns a valid response, update the quote object
      // TODO: Do better data validation/parsing
      if (data) {
        quote.quote = data.quote;
        quote.person = data.person || "Unknown Author";
        quote.image = data.image || null;
      }
    } catch (error) {
      // TODO: Add error handling!
    }

    // TODO: Handling missing data better, now we just adding "Unknown" texts
    this.elmText.textContent = quote.quote ?? "No quote available";
    this.elmAuthor.textContent = quote.person ?? "Unknown Author";

    // If the image is available, set it, otherwise remove the image element
    if (quote.image) {
      this.elmImage.alt = quote.person ?? "Unknown Author";
      this.elmImage.src = quote.image ?? "";
      this.elmRoot.appendChild(this.elmImage);
    } else {
      this.elmImage.remove();
    }

    // Set the component state to accessible, which means we are done fetching data
    this._setAsAccessible();
  }
}
