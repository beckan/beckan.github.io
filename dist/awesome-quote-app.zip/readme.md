# Awesome random quote app

Jag hade problem med att komma åt APIet pga CORS problem, servern verkar inte tillåta anrop från okända locations.
Jag löste dock detta genom att sätta upp en liten proxy som tunnlade requesten. I koden jag skickar här är dock fetch-requesten mot er url.
Ni kan se där hur jag skickar med API-nyckeln.

Det finns lite TODOs i koden för att poängtera saker jag inte har hunnit med och tycker man borde göra bättre.
Jag har lagt mer fokus på struktur i JS/CSS än att få med hela designen i pixel-perfect-utförande.
Jag har tex. aktivt valt bort att lägga in ikoner, att leta upp en liknande serif-font som i designen och att mobilanpassa allt, men istället lagt in loading-state för när vi hämtar data från APIet.

Jag inkluderar min lilla utvecklings/proxy-server också, den ligger i `/server`. Men det går att köra `index.html` utan den också.
